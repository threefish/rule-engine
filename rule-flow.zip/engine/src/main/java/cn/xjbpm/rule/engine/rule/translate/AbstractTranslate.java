/*
 * Copyright 2025 threefish.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package cn.xjbpm.rule.engine.rule.translate;

import cn.xjbpm.rule.engine.rule.Rule;
import cn.xjbpm.rule.engine.rule.enums.OperatorType;
import org.springframework.util.Assert;

/**
 * @author 黄川 huchuc@vip.qq.com
 * date: 2023/6/30
 */
public abstract class AbstractTranslate {

    protected String translate(Rule rule) {
        OperatorSupplier operatorSupplier = getOperatorSupplier(rule.getOperator());
        Assert.notNull(operatorSupplier, String.format("不支持的操作符号[%s]", rule.getOperator().getValue()));
        return operatorSupplier.get(rule);
    }

    protected abstract OperatorSupplier getOperatorSupplier(OperatorType operator);

}