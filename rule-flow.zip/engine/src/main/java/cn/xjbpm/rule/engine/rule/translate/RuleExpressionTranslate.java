/*
 * Copyright 2025 threefish.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package cn.xjbpm.rule.engine.rule.translate;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import cn.xjbpm.rule.engine.rule.Rule;
import cn.xjbpm.rule.engine.rule.enums.AssignmentType;
import cn.xjbpm.rule.engine.rule.enums.CombinatorType;
import cn.xjbpm.rule.engine.rule.enums.RuleType;
import cn.xjbpm.rule.engine.rule.enums.VariableType;

import java.util.ArrayList;
import java.util.List;

/**
 * @author 黄川 huchuc@vip.qq.com
 * date: 2023/6/30
 */
@SuppressWarnings("all")
public class RuleExpressionTranslate {

    public final Rule rule;
    private List<String> expressions = new ArrayList<>();
    private String expression;

    public RuleExpressionTranslate(Rule rule) {
        this.rule = rule;
    }

    public String getExpression() {
        if (this.rule == null) {
            return "";
        }
        if (StrUtil.isBlank(expression)) {
            expressions.add(rule.getCombinator().getValue());
            if (rule.isRoot() || rule.getRuleType() == RuleType.group) {
                if (CollUtil.isNotEmpty(rule.getRules())) {
                    expressions.add("(");
                    calcRules(rule.getRules());
                    expressions.add(")");
                }
            } else {
                calcRule();
            }
            if (expressions.size() > 0) {
                String start = expressions.get(0);
                if (CombinatorType.AND.getValue().equals(start) || CombinatorType.OR.getValue().equals(start)) {
                    expressions.remove(0);
                }
            }
            this.expression = StrUtil.join(" ", expressions);
        }
        return this.expression;
    }

    private void calcRule() {
        VariableType varType = rule.getVarType();
        AbstractTranslate translate = varType.getTranslate();
        expressions.add(translate.translate(rule));
    }

    private void calcRules(List<Rule> rules) {
        for (int i = 0; i < rules.size(); i++) {
            Rule childRule = rules.get(i);
            if (i != 0) {
                expressions.add(rule.getCombinator().getValue());
            }
            expressions.add(new RuleExpressionTranslate(childRule).getExpression());
        }
    }


}