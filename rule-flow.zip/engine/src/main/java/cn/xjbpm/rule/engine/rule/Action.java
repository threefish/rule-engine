/*
 * Copyright 2025 threefish.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package cn.xjbpm.rule.engine.rule;

import cn.xjbpm.rule.engine.rule.enums.ActionType;
import cn.xjbpm.rule.engine.rule.enums.AssignmentType;
import cn.xjbpm.rule.engine.rule.enums.VariableType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author 黄川 huchuc@vip.qq.com
 * date: 2023/6/29
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Action {
    private String key;
    private ActionType type;
    private Object value;
    private String left;
    private String fieldValue;
    private String expressionValue;
    private List<Object> values;
    private AssignmentType assignmentType;
    private VariableType varType;
}