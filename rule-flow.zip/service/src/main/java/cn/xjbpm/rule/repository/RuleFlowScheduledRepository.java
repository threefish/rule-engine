/*
 * Copyright 2025 threefish.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package cn.xjbpm.rule.repository;

import cn.xjbpm.rule.repository.entity.RuleFlowScheduledEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author 黄川 huchuc@vip.qq.com
 */
@Repository
public interface RuleFlowScheduledRepository extends JpaRepository<RuleFlowScheduledEntity, Long>, JpaSpecificationExecutor<RuleFlowScheduledEntity> {

    /**
     * 根据规则流的唯一标识 key 获取实体
     *
     * @param key
     */
    List<RuleFlowScheduledEntity> findAllByRuleFlowKey(String key);

    /**
     * 根据规则流的唯一标识 key 删除实体
     *
     * @param key
     */
    void deleteAllByRuleFlowKey(String key);
}