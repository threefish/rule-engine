/*
 * Copyright 2025 threefish.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package cn.xjbpm.rule.engine;

import cn.xjbpm.rule.engine.definition.model.nodes.EndNode;
import cn.xjbpm.rule.engine.definition.model.RuleFlowModel;
import cn.xjbpm.rule.engine.definition.model.nodes.SequenceConnNode;
import cn.xjbpm.rule.engine.definition.model.nodes.StartNode;
import cn.xjbpm.rule.engine.definition.model.nodes.FunctionNode;
import cn.xjbpm.rule.engine.definition.parse.RuleFlowModelParse;
import cn.xjbpm.rule.engine.definition.validator.ErrorNodeMsg;
import cn.xjbpm.rule.engine.definition.validator.RuleFlowModelValidator;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

/**
 * @author 黄川 huchuc@vip.qq.com
 * date: 2022/9/29
 */
public class RuleFlowModelJsonConverterTest {

    private static final RuleFlowModelParse PROCESS_MODEL_JSON_CONVERTER = new RuleFlowModelParse();

    @Test
    void convertToJson() {

        RuleFlowModel ruleFlowModel = new RuleFlowModel();
        ruleFlowModel.setKey("test");
        ruleFlowModel.setName("测试规则流");
        ruleFlowModel.setDescription("测试规则流");

        StartNode startNode = new StartNode();
        startNode.setId("start");
        startNode.setName("规则流开始");


        FunctionNode fun1 = new FunctionNode();
        fun1.setId("f1");
        fun1.setName("函数1节点");
        fun1.setId("FUN001");


        EndNode endNode = new EndNode();
        endNode.setId("end");
        endNode.setName("规则流结束");


        SequenceConnNode start_to_f1 = new SequenceConnNode();
        start_to_f1.setId("start->>f1");
        start_to_f1.setSourceNodeKey("start");
        start_to_f1.setTargetNodeKey("f1");


        SequenceConnNode f1_to_end = new SequenceConnNode();
        f1_to_end.setId("f1->>end");
        f1_to_end.setSourceNodeKey("f1");
        f1_to_end.setTargetNodeKey("end");

        ruleFlowModel.setChildNodes(Arrays.asList(startNode, endNode, fun1, f1_to_end, f1_to_end));

        String json = PROCESS_MODEL_JSON_CONVERTER.convertToJson(ruleFlowModel);

        System.out.println(json);
    }


    @Test
    void convertToModel() {
        String json = "{\n" +
                "    \"key\":\"test\",\n" +
                "    \"name\":\"测试\",\n" +
                "    \"documentation\":\"一个测试规则流\",\n" +
                "    \"executionListeners\":[],\n" +
                "    \"nodes\": [\n" +
                "        {\n" +
                "            \"id\": \"start-00001\",\n" +
                "            \"type\": \"StartNode\",\n" +
                "            \"x\": 320,\n" +
                "            \"y\": 140,\n" +
                "            \"properties\": {\n" +
                "                \"name\": \"开始\",\n" +
                "                \"tag\": \"A1\"\n" +
                "            },\n" +
                "            \"text\": {\n" +
                "                \"x\": 320,\n" +
                "                \"y\": 140,\n" +
                "                \"value\": \"开始\"\n" +
                "            }\n" +
                "        },\n" +
                "        {\n" +
                "            \"id\": \"end-00001\",\n" +
                "            \"type\": \"EndNode\",\n" +
                "            \"x\": 640,\n" +
                "            \"y\": 160,\n" +
                "            \"properties\": {\n" +
                "                \"name\": \"结束\",\n" +
                "                \"tag\": \"A2\"\n" +
                "            },\n" +
                "            \"text\": {\n" +
                "                \"x\": 640,\n" +
                "                \"y\": 160,\n" +
                "                \"value\": \"结束\"\n" +
                "            }\n" +
                "        },\n" +
                "        {\n" +
                "            \"id\": \"00001\",\n" +
                "            \"type\": \"FunctionActivityNode\",\n" +
                "            \"x\": 460,\n" +
                "            \"y\": 260,\n" +
                "            \"properties\": {\n" +
                "                \"name\": \"执行函数\",\n" +
                "                \"tag\": \"A3\"\n" +
                "            },\n" +
                "            \"text\": {\n" +
                "                \"x\": 460,\n" +
                "                \"y\": 260,\n" +
                "                \"value\": \"执行函数\"\n" +
                "            }\n" +
                "        }\n" +
                "    ],\n" +
                "    \"edges\": [\n" +
                "        {\n" +
                "            \"id\": \"e435db55-6279-4b4a-9b37-a724589ccc65\",\n" +
                "            \"type\": \"SequenceConnNode\",\n" +
                "            \"sourceNodeId\": \"start-00001\",\n" +
                "            \"targetNodeId\": \"00001\",\n" +
                "            \"startPoint\": {\n" +
                "                \"x\": 342,\n" +
                "                \"y\": 140\n" +
                "            },\n" +
                "            \"endPoint\": {\n" +
                "                \"x\": 460,\n" +
                "                \"y\": 220\n" +
                "            },\n" +
                "            \"properties\": {},\n" +
                "            \"pointsList\": [\n" +
                "                {\n" +
                "                    \"x\": 342,\n" +
                "                    \"y\": 140\n" +
                "                },\n" +
                "                {\n" +
                "                    \"x\": 442,\n" +
                "                    \"y\": 140\n" +
                "                },\n" +
                "                {\n" +
                "                    \"x\": 460,\n" +
                "                    \"y\": 120\n" +
                "                },\n" +
                "                {\n" +
                "                    \"x\": 460,\n" +
                "                    \"y\": 220\n" +
                "                }\n" +
                "            ]\n" +
                "        },\n" +
                "        {\n" +
                "            \"id\": \"5cf962a1-001d-45e4-b93f-853accb815b7\",\n" +
                "            \"type\": \"SequenceConnNode\",\n" +
                "            \"sourceNodeId\": \"00001\",\n" +
                "            \"targetNodeId\": \"end-00001\",\n" +
                "            \"startPoint\": {\n" +
                "                \"x\": 460,\n" +
                "                \"y\": 300\n" +
                "            },\n" +
                "            \"endPoint\": {\n" +
                "                \"x\": 640,\n" +
                "                \"y\": 182\n" +
                "            },\n" +
                "            \"properties\": {},\n" +
                "            \"pointsList\": [\n" +
                "                {\n" +
                "                    \"x\": 460,\n" +
                "                    \"y\": 300\n" +
                "                },\n" +
                "                {\n" +
                "                    \"x\": 460,\n" +
                "                    \"y\": 400\n" +
                "                },\n" +
                "                {\n" +
                "                    \"x\": 640,\n" +
                "                    \"y\": 282\n" +
                "                },\n" +
                "                {\n" +
                "                    \"x\": 640,\n" +
                "                    \"y\": 182\n" +
                "                }\n" +
                "            ]\n" +
                "        }\n" +
                "    ]\n" +
                "}";

        RuleFlowModel ruleFlowModel = PROCESS_MODEL_JSON_CONVERTER.convertToModel(json);

        RuleFlowModelValidator ruleFlowModelValidator = new RuleFlowModelValidator();
        List<ErrorNodeMsg> errorNodeMsgs = ruleFlowModelValidator.check(ruleFlowModel);

        String json2 = PROCESS_MODEL_JSON_CONVERTER.convertToJson(ruleFlowModel);

        System.out.println(ruleFlowModel);
        System.out.println(errorNodeMsgs);
        System.out.println(json2);
    }

}